import NormalA from 'components/A';

const RepoLink = NormalA.extend`
  height: 100%;
  color: black;
  display: flex;
  align-items: center;
  width: 100%;
`;

export default RepoLink;
